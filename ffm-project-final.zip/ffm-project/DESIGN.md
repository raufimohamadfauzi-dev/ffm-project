---
name: Kinetic Reserve
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#3f4948'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#6f7979'
  outline-variant: '#bec9c8'
  surface-tint: '#096969'
  primary: '#004c4c'
  on-primary: '#ffffff'
  primary-container: '#006666'
  on-primary-container: '#93e1e0'
  inverse-primary: '#86d4d3'
  secondary: '#006d37'
  on-secondary: '#ffffff'
  secondary-container: '#6bfe9c'
  on-secondary-container: '#00743a'
  tertiary: '#8d0304'
  on-tertiary: '#ffffff'
  tertiary-container: '#af241a'
  on-tertiary-container: '#ffc6bd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a2f0ef'
  primary-fixed-dim: '#86d4d3'
  on-primary-fixed: '#002020'
  on-primary-fixed-variant: '#004f4f'
  secondary-fixed: '#6bfe9c'
  secondary-fixed-dim: '#4ae183'
  on-secondary-fixed: '#00210c'
  on-secondary-fixed-variant: '#005228'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#ffb4a9'
  on-tertiary-fixed: '#410000'
  on-tertiary-fixed-variant: '#910807'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  data-lg:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  data-md:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 16px
  stack-gap-sm: 8px
  stack-gap-md: 16px
  stack-gap-lg: 24px
  card-gutter: 12px
---

## Brand & Style

The design system is engineered for family financial management, prioritizing a sense of security, clarity, and shared responsibility. The brand personality is **calm, authoritative, and inclusive**, ensuring that complex financial data feels manageable and approachable for all family members.

The visual style is **Modern Corporate with Tactile Affordances**. It utilizes a clean, card-based architecture that feels organized and stable. The interface avoids aggressive financial tropes, opting instead for a "Safe Harbor" aesthetic—utilizing soft backgrounds, precise data visualization, and generous white space to reduce cognitive load during budgeting and expense tracking.

## Colors

The palette is anchored by **Deep Teal**, a color that communicates professional stability and growth. 

- **Primary (Deep Teal):** Used for navigation, primary actions, and brand identification. 
- **Positive Accent (Emerald Green):** Reserved exclusively for growth indicators, savings goals met, and positive cash flow.
- **Negative Accent (Soft Coral):** Used for overages and alerts, balanced to be visible without causing anxiety.
- **Neutral (Warm Alabaster):** A soft, warm grey used for the base background and card containers to reduce glare and improve reading endurance.

## Typography

This design system uses a dual-font approach to maximize readability. 

**Hanken Grotesk** serves as the primary typeface for all interface copy, providing a contemporary, high-legibility sans-serif feel. 

**JetBrains Mono** is utilized specifically for currency, percentages, and financial figures. Its monospaced nature ensures that decimal points and numbers align perfectly in lists, facilitating easier vertical scanning of family expenses. All financial figures must use tabular lining to prevent "jumping" when values update in real-time.

## Layout & Spacing

The layout follows a **Strict Card-Based Grid**. On mobile devices, content is housed within edge-to-edge or inset cards with a standard horizontal margin of 16px.

- **The 4px Rule:** All spacing and sizing must be multiples of 4px to maintain visual mathematical harmony.
- **Vertical Rhythm:** Group related items (like a budget label and its progress bar) with 8px spacing. Separate distinct financial categories with 24px spacing.
- **Information Density:** Use generous internal padding within cards (20px) to ensure that data visualizations like rings and bars have enough "air" to be interpreted at a glance.

## Elevation & Depth

This design system uses **Tonal Layering** rather than heavy shadows to indicate hierarchy.

1.  **Level 0 (Background):** The Warm Grey (#F8F9FA) canvas.
2.  **Level 1 (Cards):** Pure White (#FFFFFF) surfaces with a subtle 1px border (#E9ECEF). No shadow is used here to maintain a "flat-modern" look.
3.  **Level 2 (Active States/Modals):** Elements that require focus use a very soft, highly diffused ambient shadow (Color: Primary, Opacity: 4%, Blur: 20px).

Depth is communicated primarily through color contrast: white cards pop against the off-white background, and primary buttons use solid fills to sit "atop" the interface.

## Shapes

The shape language is **Friendly but Disciplined**. 

- **Primary Containers:** Cards and input fields use a 0.5rem (8px) radius, striking a balance between professional geometry and modern softness.
- **Interactive Elements:** Buttons use a fully rounded "pill" shape (rounded-xl) to distinguish them from informational cards.
- **Data Visuals:** Progress bars must have fully rounded end-caps to evoke a sense of "completion" and "flow." Budget rings should use a stroke width of at least 8px for tactile visibility.

## Components

### Buttons
- **Primary:** Solid Deep Teal fill, white text, pill-shaped. High emphasis.
- **Secondary:** Deep Teal outline (2px), transparent fill. Used for "Add Expense" or "View Details."

### Financial Progress Indicators
- **Progress Bars:** Background track is a 10% opacity version of the primary color. The fill is Primary (default), Green (on track), or Red (over budget).
- **Goal Rings:** Circular gauges with the percentage centered in JetBrains Mono.

### Cards
- Standard containers for family accounts. Must include a header (Hanken Grotesk) and a primary value (JetBrains Mono).
- Swipe actions should be used for quick categorization of transactions.

### Input Fields
- Underlined or softly boxed with 8px radius. 
- Focus state is indicated by a 2px Deep Teal bottom border. 
- Currency inputs should automatically trigger a numeric keypad with a decimal point.

### Chips
- Used for transaction categories (e.g., "Groceries," "Utilities"). Small, pill-shaped with light-teal backgrounds and dark-teal text.