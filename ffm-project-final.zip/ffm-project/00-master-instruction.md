# Family Finance Manager (FFM)
## Master Instruction untuk AI Agent — v1.2 (Final V1 Scope)

Dokumen ini adalah **satu-satunya sumber kebenaran (single source of truth)** untuk agent AI yang membangun aplikasi ini. Isinya menggabungkan Product & Technical Spec v1.0, Financial Rules & AI Readiness v1.1, dan Feature Backlog tambahan — semua sudah dimasukkan ke scope **V1**.

Tujuan dokumen ini rangkap dua: jadi instruksi kerja untuk agent, dan jadi referensi lengkap buat pemilik produk (kamu) supaya tahu persis fitur & fungsi apa saja yang dibangun.

---

## 0. Ringkasan Proyek

FFM adalah aplikasi keuangan keluarga **offline-first** untuk pasangan (Suami & Istri) yang berbagi satu database keluarga. Mencatat pemasukan, pengeluaran, aset, hutang, dan target keuangan, lalu memberi skor kesehatan keuangan dan rekomendasi berbasis rule engine (bukan AI) di V1.

**Prinsip wajib dipegang agent:**
- Offline First — aplikasi harus tetap berfungsi penuh tanpa internet.
- Data Ownership — semua data tersimpan lokal, terenkripsi.
- Explainable Logic — semua skor/rekomendasi harus bisa dijelaskan dengan rumus, bukan black-box.
- Simple Input, Detailed Analysis.

---

## 1. Tech Stack

- Flutter
- Bloc (state management)
- Drift (ORM di atas SQLite)
- SQLite + SQLCipher (enkripsi database)
- Freezed (model/data class)
- GoRouter (navigasi)
- SQLite FTS5 (full-text search)
- Google ML Kit (OCR)
- Speech To Text (voice input)
- JSON Export/Import (backup)

Platform: **Android, offline-first.**

---

## 2. User Model & Autentikasi

- Dua user tetap: **Suami** dan **Istri**, masing-masing punya PIN sendiri (6 digit).
- Login pakai PIN masing-masing.
- Database dienkripsi pakai SQLCipher.
- **Tambahan V1:** Biometric unlock (fingerprint/face) sebagai shortcut opsional, PIN tetap wajib sebagai fallback.

---

## 3. Ownership Model

Semua data ada dalam satu database keluarga. Setiap transaksi punya owner: `SUAMI`, `ISTRI`, atau `KELUARGA`.

Contoh: Gaji Suami → owner `SUAMI`. Belanja bulanan → owner `KELUARGA`.

---

## 4. Financial Dictionary

**Pendapatan**: Gaji, Bonus, THR, Freelance, Bisnis, Dividen, dll — segala yang menambah nilai ekonomi.

**Pengeluaran**: Makan, Transport, Listrik, Internet, Pendidikan, dll — segala yang mengurangi uang.

**Aset**:
- Kas: Tunai, Rekening Bank, E-Wallet
- Investasi: Emas, Saham, Reksa Dana
- Fisik: Motor, Mobil, Rumah, Tanah

**Hutang**: KPR, Kredit Motor, Kartu Kredit, Paylater, Pinjaman Bank.

**Target Keuangan (Goal)**: Dana Darurat, Umroh, Rumah, Pendidikan Anak.

---

## 5. Formula Keuangan Inti

```
Cashflow      = Total Pendapatan - Total Pengeluaran
Net Worth     = Total Aset - Total Hutang
Saving Rate   = Tabungan / Pendapatan x 100
Debt Ratio    = Total Cicilan Bulanan / Pendapatan Bulanan x 100
```

---

## 6. Master Categories

**Pendapatan**: Gaji, Bonus, THR, Freelance, Bisnis, Investasi, Lainnya
**Pengeluaran**: Makanan, Transport, Rumah Tangga, Pendidikan, Kesehatan, Internet, Listrik, Air, Hiburan, Donasi, Lainnya
**Aset**: Tunai, Rekening, Deposito, Emas, Saham, Reksa Dana, Motor, Mobil, Rumah, Tanah
**Hutang**: KPR, Kredit Motor, Kredit Mobil, Kartu Kredit, Paylater, Pinjaman Pribadi
**Goal**: Dana Darurat, Umroh, Rumah, Kendaraan, Pendidikan Anak

**Tambahan V1:** User bisa membuat **subkategori custom tanpa batas** di bawah kategori induk manapun, tanpa mengubah struktur rule engine yang berbasis kategori induk.

---

## 7. Financial Health Score (0–100)

| Komponen | Bobot | Kondisi | Nilai |
|---|---|---|---|
| Cashflow Score | 25% | Positif / Negatif | 25 / 0 |
| Saving Score | 25% | ≥20% / 10-19% / <10% | 25 / 15 / 5 |
| Debt Score | 25% | ≤20% / 21-35% / >35% | 25 / 15 / 5 |
| Emergency Fund Score | 25% | ≥6bln / 3-5bln / <3bln | 25 / 15 / 5 |

**Klasifikasi Status:**
Excellent 85-100 · Good 70-84 · Fair 50-69 · Warning 30-49 · Critical 0-29

---

## 8. Dana Darurat, Goal Tracking & Prediksi

```
Dana Darurat Coverage = Dana Darurat / Rata-rata Pengeluaran Bulanan
Goal Progress          = Current Amount / Target Amount x 100
Goal Prediction         = Sisa Target / Rata-rata Tabungan Bulanan
```

**Tambahan V1:** Notifikasi **milestone goal** otomatis di 25%, 50%, 75%, 100% progress.

---

## 9. Asset Valuation Rules

| Jenis | Cara Nilai |
|---|---|
| Tunai / Rekening / E-Wallet | Nominal/Saldo saat ini |
| Emas | Berat x Harga saat ini |
| Motor/Mobil/Rumah/Tanah | Estimasi nilai pasar |

---

## 10. Debt Model

Field: Nama Hutang, Nominal Awal, Sisa Hutang, Tanggal Mulai, Jatuh Tempo, Cicilan Bulanan.

**Tambahan V1 — Debt Payoff Strategy:**
- **Snowball**: urutkan pelunasan dari sisa hutang terkecil (motivasi psikologis).
- **Avalanche**: urutkan dari beban cicilan/bunga tertinggi (paling hemat finansial).
- Output rule-based, harus bisa dijelaskan — bukan prediksi AI.

**Tambahan V1 — Bill & Cicilan Reminder:**
- Notifikasi lokal H-3 sebelum Jatuh Tempo hutang.
- Notifikasi lokal H-1 sebelum tanggal recurring transaction bulanan (listrik, internet, KPR).

---

## 11. Recurring Transactions

Jenis: Harian (parkir langganan), Mingguan (belanja pasar), Bulanan (listrik, internet, KPR), Tahunan (pajak kendaraan).

---

## 12. Merchant Recognition

Master merchant (Indomaret, Alfamart, Shopee, Tokopedia, dst). OCR mencocokkan teks nota (mis. "INDOMARET") ke merchant master.

---

## 13. Attachment, Notes, Tags, Transaction Source, Audit Log

- **Attachment**: JPG, PNG, PDF, Voice Recording.
- **Notes**: catatan bebas per transaksi, searchable via FTS5.
- **Tags**: bebas dibuat user (Liburan, Anak, Darurat, Mudik), satu transaksi bisa multi-tag.
- **Transaction Source**: Manual, OCR, Voice, Import.
- **Audit Log**: mencatat User, Action, Entity, Old Value, New Value untuk setiap perubahan data.

---

## 14. OCR Specification

Input foto nota → Google ML Kit → output merchant, item, total. Contoh: "INDOMARET / Susu 21000 / Roti 15000 / Total 48000" → tersimpan sebagai transaksi dengan item breakdown.

---

## 15. Voice Input

Contoh input: *"Belanja sayur seratus lima puluh ribu untuk keluarga"* → output kategori Makanan, nominal 150000, owner Keluarga. **User wajib konfirmasi sebelum data disimpan.**

---

## 16. Search Engine

SQLite FTS5, offline, mendukung pencarian transaksi, merchant, catatan, dan item nota.

---

## 17. Rule Engine

| Rule | Kondisi | Status |
|---|---|---|
| 001 | Debt Ratio > 35% | Warning |
| 002 | Saving Rate < 10% | Warning |
| 003 | Dana Darurat < 3 bulan pengeluaran | Warning |
| 004 | Pengeluaran Makanan > 35% | Review Spending |

**Tambahan V1 — Budget Rule:**

| Kondisi (% anggaran terpakai) | Status |
|---|---|
| ≥ 100% | Over Budget |
| 80-99% | Warning |
| < 80% | Aman |

---

## 17b. Smart Advisor Engine (Rule-Based, "AI Lokal")

Ini bukan model AI/LLM — melainkan perluasan Rule Engine (bagian 17) yang tadinya cuma menghasilkan status (Warning/Aman), sekarang juga menghasilkan **kalimat saran otomatis** dari template + kalkulasi. 100% offline, tidak butuh model, hasilnya selalu bisa dijelaskan (sesuai prinsip Explainable Logic).

### Rule Saran (Template-Based)

**a. Spending Trend Alert**
```
Jika Pengeluaran Kategori Bulan Ini > Rata-rata 3 Bulan Terakhir x 1.15
→ "Pengeluaran [Kategori] bulan ini naik [X]% dibanding rata-rata 3 bulan terakhir."
```

**b. Savings Advisor**
```
Simulasi: jika Pengeluaran Kategori dikurangi N% (default 10%),
hitung ulang Goal Prediction (bagian 8) dengan tambahan tabungan tsb.
→ "Jika mengurangi pengeluaran [Kategori] sebesar 10%, target [Goal] bisa
   tercapai [Y] bulan lebih cepat."
```

**c. Goal Advisor**
```
Tambahan Tabungan Bulanan Dibutuhkan =
  (Target Amount - Current Amount) / Bulan Tersisa Sampai Target Date
  - Rata-rata Tabungan Bulanan Saat Ini
→ "Untuk mencapai target [Goal] pada [Target Date], dibutuhkan tabungan
   tambahan Rp[nominal] per bulan."
```

**d. Budget Advisor**
```
Jika status budget kategori = Over Budget atau Warning (bagian 17, budget rule)
→ "Sisa bulan ini, kurangi pengeluaran [Kategori] sekitar Rp[nominal]
   agar tidak melebihi anggaran."
```

**e. Debt Advisor**
```
Menggunakan hasil Debt Payoff Strategy (bagian 10)
→ "Fokuskan pelunasan ke [Nama Hutang] dulu berdasarkan strategi [Snowball/Avalanche]
   yang dipilih."
```

Semua saran ini muncul otomatis di Dashboard sebagai kartu "Saran", dihitung ulang tiap kali data relevan berubah — tidak perlu trigger manual dari user.

---

## 18. Fitur Tambahan V1 (Detail)

### a. Budget Planning (Zero-Based)
User set anggaran per kategori per bulan. Sistem hitung sisa anggaran & persen terpakai (rumus & rule di atas).

### b. Cashflow Forecast
```
Prediksi Cashflow Bulan Depan =
  Rata-rata Pendapatan Recurring
  - Total Cicilan/Tagihan Recurring
  - Rata-rata Pengeluaran Non-Recurring (3 bulan terakhir)
```
Ditampilkan di Dashboard sebagai proyeksi sederhana, bukan AI.

### c. Export Laporan PDF
Berisi ringkasan bulanan, Financial Health Score + breakdown, grafik kategori, daftar goal & progress. Pelengkap backup JSON yang sudah ada.

### d. Owner Comparison View
Perbandingan total pendapatan & pengeluaran antar Suami/Istri/Keluarga, ditampilkan grafik pie/bar.

### e. Sinking Fund (Dana Terencana)
Untuk pengeluaran besar musiman (lebaran, sekolah, servis kendaraan), target < 12 bulan. Formula progress & prediksi sama seperti Goal.

### f. Weekly Digest
Ringkasan mingguan offline (pengeluaran minggu ini vs lalu, kategori terbesar, progress goal), tampil sebagai kartu di Dashboard — bukan email.

---

## 19. Dashboard

**Ringkasan**: Total Saldo, Cashflow Bulan Ini, Total Aset, Total Hutang, Net Worth, Financial Health Score, Owner Comparison, Weekly Digest, kartu Saran (Smart Advisor).

**Grafik**: Pengeluaran Bulanan, Pendapatan Bulanan, Kategori Pengeluaran, Pertumbuhan Aset, Cashflow Forecast.

---

## 20. Database Schema (Konsolidasi Semua Tabel)

```
households(id, name, created_at)   -- 1 baris per instalasi app di V1, generate UUID lokal saat Setup Awal
users(id, household_id, name, pin_hash)
transactions(id, household_id, date, amount, owner, category_id, note, updated_at, synced_at, is_deleted)
transaction_items(id, transaction_id, item_name, price, qty)
categories(id, name, type, parent_id)  -- parent_id: dukung subkategori custom
assets(id, household_id, name, value, updated_at, synced_at, is_deleted)
liabilities(id, household_id, name, remaining_balance, original_amount, start_date, due_date, monthly_installment, updated_at, synced_at, is_deleted)
goals(id, household_id, name, target_amount, current_amount, target_date, updated_at, synced_at, is_deleted)
merchants(id, name)
attachments(id, transaction_id, file_path)
budgets(id, household_id, category_id, month, amount, owner, updated_at, synced_at, is_deleted)
reminders(id, source_type, source_id, due_date, notified)
sinking_funds(id, household_id, name, target_amount, current_amount, target_date, updated_at, synced_at, is_deleted)
tags(id, name)
transaction_tags(transaction_id, tag_id)
audit_log(id, user, action, entity, old_value, new_value, timestamp)
```

**Penting:** `household_id` ditambahkan ke skema sejak V1, walau di V1 cuma ada 1 household per instalasi (offline, tidak terlihat user). Tujuannya supaya saat V2 sync diaktifkan, skema lokal & cloud sudah identik — tidak perlu migrasi/restrukturisasi database, dan siap dipasangi Row Level Security (lihat 22.8) tanpa mengganggu data yang sudah ada.

Kolom `updated_at`, `synced_at`, `is_deleted` sudah disiapkan sejak V1 di tabel-tabel utama (bukan tabel referensi seperti `categories`/`merchants`/`tags`) — supaya V2 tinggal pakai, tidak perlu migrasi schema besar nanti.

### Tabel Tambahan V2 (belum aktif di V1, lihat bagian 22)

```
subscriptions(id, user_id, plan, status, expires_at, provider)   -- 22.6
sync_queue(id, table_name, record_id, operation, payload, synced) -- 22.6
ai_usage_log(id, user_id, date, request_count)                    -- 22.6
app_config(key, value, updated_at)                                 -- 22.7
```

---

## 21. Backup

Format JSON, mendukung Export, Import, Restore. Semua data (termasuk budgets, sinking_funds, reminders) harus ikut dalam backup.

---

## 22. V2 — Cloud Sync & Pro/AI Monetization

**Status: belum dibangun di V1.** Tapi schema V1 (bagian 20) harus disiapkan agar V2 tinggal nambah, bukan rombak ulang — tambahkan kolom `updated_at`, `synced_at`, `is_deleted` di semua tabel utama sejak V1.

### 22.1 Kenapa Supabase (bukan Firebase)

- Postgres = relational, cocok langsung dengan schema Drift/SQLite yang sudah ada di bagian 20 — migrasi tinggal mirror, bukan desain ulang.
- Supabase open source & bisa **self-host** jangka panjang (lihat 22.8). Firebase terkunci selamanya di infrastruktur Google, tidak bisa self-host.
- Model harga Postgres lebih predictable untuk app dashboard/analitik-berat dibanding Firestore yang charge per read — riset internal (bagian percakapan proyek) menunjukkan Firestore rawan "read amplification" begitu ada fitur AI yang baca ulang data.

### 22.2 Arsitektur Hybrid Sync

```
SQLite (lokal, sumber utama, selalu ada, semua fitur V1 tetap 100% offline)
   ⇅ sync saat online, HANYA untuk user Pro
Supabase Postgres (cloud mirror — multi-device sync + AI)
```

- Conflict resolution: **Last-Write-Wins** berdasarkan `updated_at` (cukup untuk keluarga 2 user).
- Sync lewat **sync queue table** lokal — antrian perubahan yang belum ke-push, diproses tiap app kebuka & ada internet.
- Delete pakai soft-delete (`is_deleted`) supaya ikut ke-sync, bukan hilang begitu saja.

### 22.3 Free vs Pro

| | Free | Pro |
|---|---|---|
| Semua fitur V1 (transaksi, budget, goal, rule engine, Smart Advisor rule-based) | ✅ 100% offline | ✅ |
| Cloud Sync multi-device (Supabase) | ❌ | ✅ |
| AI Insight (LLM) | ❌ | ✅ |

### 22.4 AI Insight (Smart Advisor versi LLM, Pro-only)

- App **tidak pernah** panggil Gemini langsung — selalu lewat Supabase Edge Function `/ai-insight`.
- Edge Function alurnya: (1) cek status Pro dari tabel `subscriptions`, tolak kalau bukan Pro → (2) kalau Pro, ambil data **hanya dari Financial Summary View** (Total Pendapatan, Pengeluaran, Aset, Hutang, Goal, Score — sesuai prinsip AI Readiness: AI tidak boleh baca raw database) → (3) kirim ke Gemini API → (4) balikin hasil ke app.
- API key Gemini disimpan sebagai environment variable di Edge Function — **tidak pernah** ada di kode app (App tidak bisa di-decompile untuk curi key).
- **Rate limit wajib**: maksimal N request AI/hari per user (misal 20x), dicatat di `ai_usage_log`, supaya biaya LLM tidak membengkak tak terkendali walau semua user Pro pakai AI.
- Kalau kuota habis: tampilkan pesan "kuota AI hari ini habis", bukan diblokir total dari fitur lain.

### 22.5 Billing / Status Pro

Pakai **RevenueCat** untuk urus Play Billing + validasi status subscription otomatis, hasilnya disinkron ke tabel `subscriptions` di Supabase yang jadi rujukan Edge Function.

### 22.6 Tabel Baru untuk V2

```
subscriptions(id, user_id, plan, status, expires_at, provider)
sync_queue(id, table_name, record_id, operation, payload, synced)
ai_usage_log(id, user_id, date, request_count)
```

### 22.7 Remote Config (Kenapa Backend Penting di V2)

Prinsip: **hal yang mungkin sering berubah, jangan di-hardcode di app** — taruh di backend, supaya bisa diubah tanpa release ulang apk dan nunggu review Playstore.

Contoh yang wajib jadi remote config (bukan hardcode):
- Limit AI request harian per user (bagian 22.4)
- Threshold rule engine (misal ambang "Debt Ratio > 35%" — kalau nanti mau di-tuning)
- On/off fitur tertentu (feature flag) — misal mau matikan sementara fitur AI kalau biaya lagi membengkak, tanpa perlu update app

App/Edge Function baca config ini saat runtime (di-cache lokal biar tetap jalan walau offline, di-refresh saat online).

### Tabel Baru: `app_config`
```
app_config(key, value, updated_at)
-- contoh row: ('ai_daily_limit', '20', ...), ('feature_ai_enabled', 'true', ...)
```

---

### 22.8 Isolasi Data Antar Household (Row Level Security)

Karena ribuan keluarga (household) akan berbagi satu database Supabase yang sama di V2, wajib dipasang **Row Level Security (RLS)** di setiap tabel yang ikut sync — supaya keluarga A secara teknis **tidak bisa** membaca/menulis data keluarga B, walau sama-sama connect ke database yang sama.

Aturan RLS: setiap query otomatis difilter `WHERE household_id = <household milik user yang sedang login>` di level database — bukan cuma dicek di kode app (kalau cuma dicek di app, bisa dilewati kalau ada bug atau orang iseng manggil API langsung).

`household_id` sudah tersedia sejak V1 (lihat bagian 20), jadi RLS tinggal dipasang di V2 tanpa perlu tambah kolom baru ke tabel yang sudah ada datanya.

---

### 22.9 Strategi Migrasi Jangka Panjang

Dua komponen ini bermigrasi **independen**, tidak harus barengan:

| Komponen | Mulai dari | Migrasi ke self-hosted kalau... |
|---|---|---|
| Database | Supabase Cloud (Free → Pro $25/bln) | Tagihan bulanan Supabase Cloud sudah lebih mahal dari sewa+kelola Postgres sendiri di VPS |
| AI/LLM | Gemini API (pay-per-token) | Biaya token bulanan sudah lebih mahal dari sewa VPS+GPU buat self-host Qwen 24/7 lewat Ollama |

Karena Supabase pakai Postgres standar (open source), migrasi database nanti = pindah hosting dengan schema & kode yang sama persis, bukan rewrite total.

---

## 23. Performance Target

- Startup < 2 detik
- Search < 200 ms
- Dashboard < 1 detik
- Tetap responsif hingga 100.000+ transaksi

---

## 24. Success Criteria (V1)

- Seluruh transaksi keluarga tercatat, termasuk lewat OCR & Voice.
- Semua data dapat dicari offline (FTS5).
- Budget, Goal, Sinking Fund dapat dipantau progresnya.
- Hutang dapat dilacak + rekomendasi strategi pelunasan.
- Aset dihitung otomatis ke Net Worth.
- Financial Health Score akurat sesuai rumus.
- Reminder tagihan/cicilan berjalan H-3/H-1.
- Saran otomatis (Smart Advisor) muncul di Dashboard tanpa perlu ditrigger manual, dan selalu bisa dijelaskan asal rumusnya.
- Backup JSON & Export PDF berjalan.
- Semua berjalan tanpa internet.

---

## 25. Roadmap

**V1 (dibangun sekarang — semua di bawah ini termasuk fitur tambahan):**
Transaksi, Aset, Hutang (+ payoff strategy), Goal (+ milestone notif), Budget Planning, Bill/Cicilan Reminder, Sinking Fund, Owner Comparison, Cashflow Forecast, Custom Subcategory, Biometric Unlock, Weekly Digest, Smart Advisor Engine (rule-based), OCR, Voice, Dashboard, Search, Export PDF, JSON Backup.

**V2:** Cloud Sync (Supabase, hybrid dengan SQLite lokal), Pro/Free monetization (RevenueCat), AI Insight berbasis LLM (Gemini via Supabase Edge Function, rate-limited, Pro-only) — detail lengkap di bagian 22.

**V3:** Financial Coach, Predictive Analytics, Offline AI Assistant.

---

## 26. Struktur Folder Project (Feature-First, Clean Architecture)

Pola ini yang dipakai proyek Flutter production saat ini (bukan folder global `models/`, `screens/` dicampur semua fitur) — setiap fitur berdiri sendiri, dipecah jadi `data/domain/presentation`, supaya gampang dicari, di-maintain, dan ditest terpisah. Ikuti struktur ini persis, jangan bikin variasi sendiri.

```
lib/
├── main.dart
│
├── core/                         # Semua yang dipakai lintas fitur
│   ├── database/                 # Setup Drift, migrations, koneksi SQLCipher
│   ├── router/                   # GoRouter config
│   ├── di/                       # Dependency injection (get_it)
│   ├── theme/                    # Warna, tipografi (sesuai ui-stitch-brief.md)
│   ├── constants/                # Master Categories & Financial Dictionary (bagian 4, 6)
│   ├── errors/                   # Exception & Result/Either wrapper
│   ├── utils/                    # Formatter rupiah, date helper, dsb
│   └── config/                   # Klien remote config (V2, bagian 22.7) — kosong/stub di V1
│
├── features/
│   ├── auth/                     # PIN, biometric
│   ├── transaction/               # CRUD, OCR, voice input
│   ├── budget/                    # Budget planning (bagian 18a)
│   ├── asset/
│   ├── liability/                 # Hutang + payoff strategy (bagian 10)
│   ├── goal/
│   ├── sinking_fund/
│   ├── dashboard/                 # Grafik, Financial Health Score
│   ├── advisor/                   # Rule Engine + Smart Advisor (bagian 17, 17b)
│   ├── reminder/                  # Bill & cicilan reminder
│   ├── search/                    # FTS5
│   ├── backup/                    # Export PDF, JSON export/import
│   ├── settings/
│   │
│   ├── sync/                      # === V2, folder disiapkan tapi KOSONG di V1 ===
│   └── ai_insight/                # === V2, folder disiapkan tapi KOSONG di V1 ===
│
└── shared/                        # Widget dipakai berulang lintas fitur
    ├── widgets/                   # progress ring, category icon, kartu saran, dst
    └── extensions/
```

### Isi Setiap Folder Fitur (`features/<nama_fitur>/`)

```
<nama_fitur>/
├── data/
│   ├── models/            # 1 file per model (Freezed), fromJson/toJson/fromDrift
│   ├── datasources/        # local (Drift), ocr_datasource.dart, voice_datasource.dart, dsb
│   └── repositories/       # implementasi konkret dari domain/repositories
│
├── domain/
│   ├── entities/            # 1 file per entity, pure Dart, tanpa dependency Flutter
│   ├── repositories/        # abstract interface (contract)
│   └── usecases/            # 1 file per use case, single responsibility
│       # contoh: calculate_debt_ratio.dart, get_goal_prediction.dart
│
└── presentation/
    ├── bloc/                # 1 folder per bloc: xxx_bloc.dart, xxx_event.dart, xxx_state.dart (Freezed)
    ├── pages/               # 1 file per layar (sesuai daftar di ui-stitch-brief.md)
    └── widgets/             # widget khusus fitur ini saja (bukan shared)
```

### Aturan Wajib

1. **Satu file = satu tanggung jawab.** Jangan gabung banyak class/function nggak berhubungan dalam satu file besar — ini yang bikin susah di-maintain saat fitur bertambah.
2. **Dependency cuma boleh mengarah ke dalam**: `presentation` → `domain` ← `data`. `domain` tidak boleh import apapun dari Flutter/Drift/package luar — supaya business logic (rumus di bagian 5-10) bisa di-unit-test tanpa UI.
3. **Rule Engine, Financial Health Score, Smart Advisor Engine (bagian 17, 17b)** wajib jadi `usecases/` murni di `domain/`, bukan logic yang nempel di widget — supaya gampang dites & tidak ikut berubah kalau UI diganti.
4. **Fitur baru = folder baru** di `features/`, ikuti struktur `data/domain/presentation` yang sama — ini yang bikin nambah fitur ke depan (V2, V3, atau ide baru) tidak mengganggu fitur lain yang sudah jalan.
5. Folder `sync/` dan `ai_insight/` **dibuat kosong dari V1** (cukup file placeholder), supaya struktur project sudah "siap slot" untuk V2 tanpa restrukturisasi folder besar-besaran nanti.

---

## 27. Instruksi Kerja untuk Agent

0. **Buat struktur folder sesuai bagian 26 terlebih dulu** (termasuk folder kosong `sync/` dan `ai_insight/`), sebelum menulis file apapun.
1. **Sebelum menulis kode apapun, cek versi terbaru semua dependency** (Flutter, Bloc, Drift, Freezed, GoRouter, SQLCipher, Google ML Kit, Speech To Text, dan package pendukung lain) lewat pub.dev atau dokumentasi resmi masing-masing. Jangan pakai versi dari memori/training data begitu saja — versi yang diingat bisa sudah usang atau deprecated. Gunakan versi stable terbaru yang kompatibel satu sama lain, dan catat versi yang dipakai di `pubspec.yaml`.
2. Bangun database schema (Drift) lengkap dulu sesuai bagian 20, termasuk tabel baru — ini fondasi semua fitur.
3. Implementasi core CRUD: transaksi, aset, hutang, goal, budget, sinking fund.
4. Implementasi rule engine & Financial Health Score sebagai pure function yang bisa di-unit-test terpisah dari UI.
5. Implementasi OCR & Voice input sebagai modul terpisah yang menghasilkan draft transaksi — user tetap wajib konfirmasi sebelum simpan.
6. Implementasi reminder & notifikasi lokal (Bill Reminder, Goal Milestone, Weekly Digest).
7. Implementasi Dashboard & grafik terakhir, setelah semua data source di atas siap.
8. Implementasi Export PDF & JSON Backup/Restore.
9. Semua fitur wajib berfungsi tanpa koneksi internet — jangan tambahkan dependency online di V1.
10. Ikuti Master Categories & Financial Dictionary di bagian 4 & 6 sebagai satu-satunya sumber nama kategori — jangan buat kategori baru di luar itu kecuali lewat fitur Custom Subcategory.

---

## 28. Cara Handoff Desain dari Stitch ke Manus

Stitch dan Manus dua tools terpisah — `ui-stitch-brief.md` cuma dipakai di Stitch, **tidak** ikut diserahkan ke Manus. Yang diserahkan ke Manus adalah hasil jadi dari Stitch + master instruction ini.

### Langkah

1. Buka Stitch (labs.google/stitch), paste prompt per layar dari `ui-stitch-brief.md` bagian 4.
2. Refine desain di Stitch sampai semua layar (lihat daftar di `ui-stitch-brief.md` bagian 2) selesai.
3. Export dari Stitch: **DESIGN.md** (format markdown khusus buat dibaca AI coding agent — paling direkomendasikan), dan opsional HTML/CSS per layar sebagai referensi tambahan.
   - Catatan: Stitch tidak export langsung ke Flutter, hasilnya cuma referensi visual — Manus yang menerjemahkan ke widget Flutter mengikuti struktur folder di bagian 26.
4. Susun semua jadi satu folder, lalu zip:

```
ffm-project/
├── 00-master-instruction.md
├── DESIGN.md                 (dari Stitch)
├── screens/                  (HTML/CSS tiap layar, opsional)
│   ├── dashboard.html
│   ├── tambah-transaksi.html
│   └── ...
```

5. Serahkan folder/zip ini ke Manus di awal project/task.

---

End of Master Instruction v1.2
